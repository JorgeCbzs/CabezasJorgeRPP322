/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial;

/**
 *
 * @author jorge
 */
public class Parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        LaboratorioTecnologico lab = new LaboratorioTecnologico();
        //ANALISIS ESTADISTICO

        cargarDatos(lab);


        //2. Mostrar proyectos registrados:  
        lab.mostrarProyectos();

        //3. Actualización de resultados: 
        //lab.actualizarResultadosProyectos();
        //4. Actualización de estado: 
        //lab.actualizarEstadoProyectos(EstadoProyecto.ENTRENANDO_MODELO);
        /*lab.agregarProyecto(a2);
        lab.agregarProyecto(a3);
        lab.agregarProyecto(a4);

        lab.agregarProyecto(m1);
        lab.agregarProyecto(m2);
        lab.agregarProyecto(m3);
        lab.agregarProyecto(m4);

        lab.agregarProyecto(v1);
        lab.agregarProyecto(v2);
        lab.agregarProyecto(v3);
        lab.agregarProyecto(v4);
        
         */
        //System.out.println(lab.mostrarProyectosPorTipo());
        //lab.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);
        //System.out.println(lab.mostrarProyectosPorTipo());
    }

    public static void cargarDatos(LaboratorioTecnologico lab) {
        
        AnalisisEstadistico a1 = new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-A", EstadoProyecto.FINALIZADO, TipoAnalisis.DESCRIPTIVO);
        AnalisisEstadistico a2 = new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.EN_DESARROLLO, TipoAnalisis.PREDICTIVO);
        AnalisisEstadistico a3 = new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.ENTRENANDO_MODELO, TipoAnalisis.PREDICTIVO);

        
        ModeloMachineLearning m1 = new ModeloMachineLearning("Prediccion de Accidentes 1", "AI-Lab-1", EstadoProyecto.EN_DESARROLLO, 80);
        ModeloMachineLearning m2 = new ModeloMachineLearning("Prediccion de Accidentes 2", "AI-Lab-2", EstadoProyecto.ENTRENANDO_MODELO, 65);
        ModeloMachineLearning m3 = new ModeloMachineLearning("Prediccion de Accidentes 3", "AI-Lab-3", EstadoProyecto.FINALIZADO, 92);

        
        SistemaVisualizacion v1 = new SistemaVisualizacion("Dashboard General", "VisualLab-A", EstadoProyecto.EN_DESARROLLO, 12);
        SistemaVisualizacion v2 = new SistemaVisualizacion("Panel de Riesgos", "VisualLab-B", EstadoProyecto.FINALIZADO, 10);
        SistemaVisualizacion v3 = new SistemaVisualizacion("Monitoreo Tiempo Real", "VisualLab-C", EstadoProyecto.ENTRENANDO_MODELO, 15);

        //1. Agregar proyectos al sistema: 
        try {
            lab.agregarProyecto(a1);
            lab.agregarProyecto(a2);
            lab.agregarProyecto(a2);
            lab.agregarProyecto(m1);
            lab.agregarProyecto(m2);
            lab.agregarProyecto(m3);
            lab.agregarProyecto(v1);
            lab.agregarProyecto(v2);
            lab.agregarProyecto(v3);

        } catch (DuplicateProjectException e) {
            System.out.println("AVISO : Se intento agregar un proyecto ya existente");
        }
        
        
        
        //lab.agregarProyecto(a3); //Causa la exception
    }

}
