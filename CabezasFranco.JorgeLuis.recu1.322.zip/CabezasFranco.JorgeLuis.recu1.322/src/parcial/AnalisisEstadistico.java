/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author jorge
 */
public class AnalisisEstadistico extends Proyecto implements Actualizable{
    private TipoAnalisis tipo;
    
    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoProyecto estado, TipoAnalisis tipo) {
        super(nombre, equipoResponsable, estado);
        this.tipo = tipo;
    }
    
    
    @Override
    public String toHeaderString(){
        return super.toHeaderString() + "%-20s|".formatted("TIPO ANALISIS");
    }
    
    @Override
    public String toRowString(){
        
        return super.toRowString() + "%-20s|".formatted(tipo.name());
    }

    @Override
    public void actualizarResultadosProyectos() {
        System.out.println("Actualizacion de resultado del Analisis: " + getNombre());
    }
            
    
    
}
