/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author jorge
 */
public class ModeloMachineLearning extends Proyecto implements Actualizable{

    private static int MIN_PRECISION = 0;
    private static int MAX_PRECISION = 100;

    private int porcentajePrecision;

    public ModeloMachineLearning(String nombre, String equipoResponsable, EstadoProyecto estado, int porcentajePrecesion) {
        super(nombre, equipoResponsable, estado);
        this.porcentajePrecision = validarPrecision(porcentajePrecesion);
        
    }

    private int validarPrecision(int precision) {
        
        if (precision < MIN_PRECISION) {
            throw new IllegalArgumentException("La precision no puede ser menor a 0");
        }else if(precision > MAX_PRECISION){
            throw new IllegalArgumentException("La precision no puede ser mayor a 100");
        }
        return precision;
    }
    
    
    @Override
    public String toHeaderString(){
        return super.toHeaderString() + "%-20s|".formatted("PORCENTAJE");
    }
    
    @Override
    public String toRowString(){
        return super.toRowString() + "%-20d|".formatted(porcentajePrecision);
    }

    @Override
    public void actualizarResultadosProyectos() {
        System.out.println("Actualizacion de resultado del Modelo: " + getNombre());
    }


}
