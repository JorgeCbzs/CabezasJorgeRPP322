/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author jorge
 */
public class SistemaVisualizacion extends Proyecto {
    private int cantidadGraficos;

    public SistemaVisualizacion(String nombre, String equipoResponsable, EstadoProyecto estado, int cantidadGraficos) {
        super(nombre, equipoResponsable, estado);
        this.cantidadGraficos = setCantidad(cantidadGraficos);
    }
    
    
    
    private int setCantidad(int cantidad){
        if (cantidad < 0){
            throw new IllegalArgumentException("La cantidad no puede ser menor a 0");
        }
        return cantidad;
    }
    
    @Override
    public String toHeaderString(){
        return super.toHeaderString() + "%-20s|".formatted("CANT. GRAFICOS");
    }
    
    @Override
    public String toRowString(){
        return super.toRowString() + "%-20d|".formatted(cantidadGraficos);
    }
    
}
