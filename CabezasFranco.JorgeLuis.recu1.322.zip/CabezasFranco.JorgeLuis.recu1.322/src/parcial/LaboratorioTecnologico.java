/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

import java.util.ArrayList;

/**
 *
 * @author jorge
 */
public class LaboratorioTecnologico {

    private ArrayList<Proyecto> proyectos;

    public LaboratorioTecnologico() {
        proyectos = new ArrayList<>();
    }

    public void agregarProyecto(Proyecto p) {
        validarProyectoNulo(p);

        if (validarProyectoRepetido(p)) {
            throw new DuplicateProjectException();
        } else {

            proyectos.add(p);
        }

    }

    public void mostrarProyectos() {
        if (validarProyectosVacio()) {
            throw new IllegalStateException("La lista de proyectos esta vacia");
        }
        System.out.println(crearTablaProyectosPorTipo());
    }

    private boolean validarProyectosVacio() {
        return proyectos.isEmpty();
    }


    private String crearTablaProyectosPorTipo() {

        if (validarProyectosVacio()) {
            throw new IllegalStateException("La lista de proyectos esta vacia");
        }
        StringBuilder sb = new StringBuilder();

        ArrayList<AnalisisEstadistico> analisis = new ArrayList<>();
        ArrayList<ModeloMachineLearning> modelos = new ArrayList<>();
        ArrayList<SistemaVisualizacion> sistemas = new ArrayList<>();

        for (Proyecto p : proyectos) {
            if (p instanceof AnalisisEstadistico) {
                analisis.add((AnalisisEstadistico) p);
            } else if (p instanceof ModeloMachineLearning) {
                modelos.add((ModeloMachineLearning) p);
            } else if (p instanceof SistemaVisualizacion) {
                sistemas.add((SistemaVisualizacion) p);
            }

        }
        if (!analisis.isEmpty()) {
            sb.append("=========================================ANALISIS ESTADISITCO=======================================");
            sb.append("\n");
            sb.append(analisis.get(0).toHeaderString());
            sb.append("\n");
            for (AnalisisEstadistico a : analisis) {
                sb.append(a.toRowString());
                sb.append("\n");
            }
            sb.append("\n");
        }
        
        if (!modelos.isEmpty()) {
            sb.append("=========================================MODELO MACHINE LEARNING====================================");
            sb.append("\n");
            sb.append(modelos.get(0).toHeaderString());
            sb.append("\n");
            for (ModeloMachineLearning m : modelos) {
                sb.append(m.toRowString());
                sb.append("\n");
            }
            sb.append("\n");
        }
        
        if (!sistemas.isEmpty()) {
            sb.append("=========================================SISTEMAS DE VISUALIZACION==================================");
            sb.append("\n");
            sb.append(sistemas.get(0).toHeaderString());
            sb.append("\n");
            for (SistemaVisualizacion s : sistemas) {
                sb.append(s.toRowString());
                sb.append("\n");
            }
            sb.append("\n");
        }
        

        return sb.toString();

    }

    private void validarActualizacion(EstadoProyecto nuevoEstado) {
        if (nuevoEstado == null) {
            throw new IllegalArgumentException("Indique un estado valido");
        }

        if (validarProyectosVacio()) {
            throw new IllegalStateException("No hay ningun proyecto");
        }
    }

    public void actualizarResultadosProyectos() {
        boolean noHaySistemas = false;
        if (validarProyectosVacio()) {
            throw new IllegalStateException("La lista de proyectos esta vacia");
        }
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable) {
                ((Actualizable) p).actualizarResultadosProyectos();
            } else {
                noHaySistemas = true;
            }

        }

        if (noHaySistemas) {
            System.out.println("Los sistemas de visualizacion no pueden ser actualizados");
        }
    }

    public void actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {

        validarActualizacion(nuevoEstado);
        int contadorCambios = 0;
        EstadoProyecto estadoActual;
        StringBuilder sb = new StringBuilder();
        sb.append("                 CAMBIOS REALIZADOS: ");
        sb.append("\n");
        sb.append("================================================================================================");
        sb.append("\n");
        for (Proyecto p : proyectos) {
            estadoActual = p.getEstado();
            if (p.actualizarEstadoProyecto(nuevoEstado)) {
                sb.append("%-28s".formatted(p.getNombre()));
                sb.append("|");
                sb.append(" Antiguo Estado: ");
                sb.append("%-22s".formatted(estadoActual.name()));
                sb.append("|");
                sb.append(" Nuevo Estado: ");
                sb.append(nuevoEstado.name());
                sb.append("\n");
                contadorCambios++;
            }

        }
        sb.append("\n");
        sb.append("Cantidad de cambios realizados: %d".formatted(contadorCambios));
        sb.append("\n");
        sb.append("================================================================================================");

        System.out.println(sb);
    }

    private void validarProyectoNulo(Proyecto p) {
        if (p == null) {
            throw new IllegalArgumentException("El proyecto no puede ser nulo");
        }
    }

    private boolean validarProyectoRepetido(Proyecto p) {
        boolean hayRepetido = false;

        for (Proyecto proyect : proyectos) {
            if (proyect.equals(p)) {
                hayRepetido = true;
            }
        }

        return hayRepetido;
    }

}
