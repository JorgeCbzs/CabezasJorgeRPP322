/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

import java.util.Objects;

/**
 *
 * @author jorge
 */
public abstract class Proyecto {
    private String nombre;
    private String equipoResponsable;
    private EstadoProyecto estado;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estado) {
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estado = estado;
    }
    
    
    public String toRowString(){
        return "|%-30s|%-25s|%-20s|".formatted(nombre,equipoResponsable,estado.name());
    }
    
    public String toHeaderString(){
        return "|%-30s|%-25s|%-20s|".formatted("NOMBRE","EQUIPO RESPONSABLE","ESTADO");
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public EstadoProyecto getEstado(){
        return estado;
    }
    
    public String getEquipo(){
        return equipoResponsable;
    }
    
    public boolean actualizarEstadoProyecto(EstadoProyecto nuevoEstado){
        boolean actualizado = false;
        if(nuevoEstado == null){
            throw new IllegalArgumentException();
        }
        if(!estado.equals(nuevoEstado)){
            estado = nuevoEstado;
            actualizado = true;
        }
        return actualizado;
    }
    
    
    @Override
    public boolean equals(Object o){
        if (o == null || !(o instanceof Proyecto p)){
            return false;
        }

        return this.nombre.equals(p.nombre) && this.equipoResponsable.equals(p.equipoResponsable);
    }

    @Override
    public int hashCode(){
        return Objects.hash(nombre,equipoResponsable);
    }
    
}
